package com.stg.entity;

public enum Payment {
	
	YES ,NO

}
